import React, { useEffect } from 'react';
import { X } from 'lucide-react';
import toast from 'react-hot-toast';

interface ScheduleConsultationProps {
  onClose: () => void;
  studentEmail: string;
  studentName: string;
}

declare global {
  interface Window {
    Calendly: {
      initInlineWidget: (config: {
        url: string;
        parentElement: HTMLElement | null;
        prefill?: {
          email?: string;
          name?: string;
        };
      }) => void;
    };
  }
}

const CALENDLY_URL = 'https://calendly.com/orbit-builder-100x/30min';

export default function ScheduleConsultation({ onClose, studentEmail, studentName }: ScheduleConsultationProps) {
  useEffect(() => {
    const initializeCalendly = () => {
      if (window.Calendly) {
        const element = document.getElementById('calendly-inline-widget');
        if (element) {
          window.Calendly.initInlineWidget({
            url: CALENDLY_URL,
            parentElement: element,
            prefill: {
              email: studentEmail,
              name: studentName,
            },
          });
        }
      } else {
        toast.error('Calendar widget failed to load');
      }
    };

    // Wait for Calendly script to load
    const checkCalendly = setInterval(() => {
      if (window.Calendly) {
        clearInterval(checkCalendly);
        initializeCalendly();
      }
    }, 100);

    // Cleanup
    return () => {
      clearInterval(checkCalendly);
    };
  }, [studentEmail, studentName]);

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl w-full max-w-4xl h-[80vh] relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-500 hover:text-gray-700 z-10"
        >
          <X className="w-5 h-5" />
        </button>
        
        <div className="p-6 pb-0">
          <h2 className="text-2xl font-bold text-gray-900">Schedule Your Consultation</h2>
          <p className="text-gray-600 mt-2">Choose a convenient time for your personalized admissions consultation.</p>
        </div>
        
        <div className="h-[calc(80vh-100px)] p-6">
          <div 
            id="calendly-inline-widget" 
            className="w-full h-full rounded-lg"
          />
        </div>
      </div>
    </div>
  );
}