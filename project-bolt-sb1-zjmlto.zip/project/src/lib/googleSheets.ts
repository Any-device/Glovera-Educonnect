import { getAuthToken } from './googleAuth';
import { Student } from './db';
import toast from 'react-hot-toast';

const SHEET_ID = '1lM29OjPDvhd7L22K6wm1_F1CXr_mYmss4xSg4BTYRIQ';

export async function appendToSheet(student: Omit<Student, 'password'>) {
  try {
    // Wait for Google API initialization
    await new Promise((resolve) => {
      gapi.load('client', resolve);
    });

    // Initialize the Google Sheets API
    await gapi.client.init({
      apiKey: import.meta.env.VITE_GOOGLE_API_KEY,
      discoveryDocs: ['https://sheets.googleapis.com/$discovery/rest?version=v4'],
    });

    // Get authentication token
    await getAuthToken();

    // Format data for sheets
    const values = [
      [
        new Date().toISOString(), // Timestamp
        student.name,
        student.email,
        student.phone,
        student.fatherName,
        student.education,
        student.preferredCourse,
        student.cgpa.toString()
      ]
    ];

    // Append the values to the sheet
    const response = await gapi.client.sheets.spreadsheets.values.append({
      spreadsheetId: SHEET_ID,
      range: 'Sheet1!A:H',
      valueInputOption: 'USER_ENTERED',
      resource: { values }
    });

    if (response.status === 200) {
      toast.success('Data saved to Google Sheets!');
      return true;
    } else {
      throw new Error('Failed to save to Google Sheets');
    }
  } catch (error) {
    console.error('Google Sheets error:', error);
    toast.error('Failed to save to Google Sheets');
    throw error;
  }
}