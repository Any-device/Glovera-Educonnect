import { getAuthToken } from './googleAuth';
import toast from 'react-hot-toast';

const SHEET_ID = import.meta.env.VITE_GOOGLE_SHEET_ID;

interface ChatbotKnowledge {
  question: string;
  answer: string;
  category: string;
}

let knowledgeBase: ChatbotKnowledge[] = [];

export async function loadChatbotData() {
  try {
    await new Promise((resolve) => {
      gapi.load('client', resolve);
    });

    await gapi.client.init({
      apiKey: import.meta.env.VITE_GOOGLE_API_KEY,
      discoveryDocs: ['https://sheets.googleapis.com/$discovery/rest?version=v4'],
    });

    await getAuthToken();

    const response = await gapi.client.sheets.spreadsheets.values.get({
      spreadsheetId: SHEET_ID,
      range: 'ChatbotData!A:C', // Assuming columns A=Question, B=Answer, C=Category
    });

    const rows = response.result.values;
    if (rows && rows.length > 0) {
      // Skip header row
      knowledgeBase = rows.slice(1).map(row => ({
        question: row[0],
        answer: row[1],
        category: row[2]
      }));
      console.log('Chatbot knowledge base loaded:', knowledgeBase.length, 'entries');
    }
  } catch (error) {
    console.error('Error loading chatbot data:', error);
    toast.error('Failed to load chatbot knowledge base');
  }
}

function findBestMatch(userInput: string): ChatbotKnowledge | null {
  const userWords = userInput.toLowerCase().split(' ');
  
  let bestMatch: ChatbotKnowledge | null = null;
  let highestScore = 0;

  knowledgeBase.forEach(entry => {
    const questionWords = entry.question.toLowerCase().split(' ');
    let matchScore = 0;

    userWords.forEach(word => {
      if (questionWords.includes(word)) {
        matchScore++;
      }
    });

    if (matchScore > highestScore) {
      highestScore = matchScore;
      bestMatch = entry;
    }
  });

  // Require at least 30% word match
  return highestScore / userWords.length >= 0.3 ? bestMatch : null;
}

export async function getChatbotResponse(userInput: string): Promise<string> {
  if (knowledgeBase.length === 0) {
    await loadChatbotData();
  }

  const match = findBestMatch(userInput);
  if (match) {
    return match.answer;
  }

  return "I apologize, but I don't have specific information about that. Would you like to schedule a consultation with our advisors to discuss this in detail?";
}