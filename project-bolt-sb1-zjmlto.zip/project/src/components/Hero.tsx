import React from 'react';
import { Calendar } from 'lucide-react';

interface HeroProps {
  onRegisterClick: () => void;
}

export default function Hero({ onRegisterClick }: HeroProps) {
  return (
    <div className="min-h-[calc(100vh-5rem)] bg-gradient-to-br from-blue-50 to-white">
      <div className="container-xl h-full py-12 lg:py-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center h-full">
          <div className="space-y-8">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight">
              Your Journey to U.S. Education Starts Here
            </h1>
            <p className="text-lg sm:text-xl lg:text-2xl text-gray-600">
              Get personalized guidance from exceptional advisors who understand your dreams and help make them reality.
            </p>
            <button 
              onClick={onRegisterClick}
              className="group inline-flex items-center bg-blue-600 text-white px-8 py-4 rounded-full text-lg font-medium hover:bg-blue-700 transition-colors"
            >
              Book a Meeting
              <Calendar className="ml-3 w-6 h-6 group-hover:transform group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
          
          <div className="relative">
            <img
              src="https://images.unsplash.com/photo-1516321318423-f06f85e504b3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1740&q=80"
              alt="Student having online consultation"
              className="rounded-2xl shadow-2xl w-full object-cover aspect-[4/3]"
            />
            <div className="absolute -bottom-8 -left-8 bg-white p-6 rounded-xl shadow-lg">
              <div className="flex items-center space-x-4">
                <div className="w-4 h-4 bg-green-500 rounded-full animate-pulse" />
                <p className="text-lg font-medium">Advisors Available Now</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}