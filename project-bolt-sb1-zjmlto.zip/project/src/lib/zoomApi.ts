import toast from 'react-hot-toast';

const ZOOM_API_URL = 'https://api.zoom.us/v2';
const ZOOM_ACCOUNT_ID = import.meta.env.VITE_ZOOM_ACCOUNT_ID;
const ZOOM_CLIENT_ID = import.meta.env.VITE_ZOOM_SDK_KEY;
const ZOOM_CLIENT_SECRET = import.meta.env.VITE_ZOOM_SDK_SECRET;

async function getZoomAccessToken() {
  try {
    const credentials = btoa(`${ZOOM_CLIENT_ID}:${ZOOM_CLIENT_SECRET}`);
    const response = await fetch('https://zoom.us/oauth/token', {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${credentials}`,
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: 'grant_type=account_credentials&account_id=' + ZOOM_ACCOUNT_ID
    });

    if (!response.ok) {
      throw new Error('Failed to get Zoom access token');
    }

    const data = await response.json();
    return data.access_token;
  } catch (error) {
    console.error('Error getting Zoom token:', error);
    throw new Error('Failed to authenticate with Zoom');
  }
}

export async function createZoomMeeting(topic: string, startTime: string, duration: number = 30) {
  try {
    const accessToken = await getZoomAccessToken();
    
    const response = await fetch(`${ZOOM_API_URL}/users/me/meetings`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        topic,
        type: 2, // Scheduled meeting
        start_time: startTime,
        duration,
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        settings: {
          host_video: true,
          participant_video: true,
          join_before_host: true,
          mute_upon_entry: false,
          watermark: false,
          use_pmi: false,
          approval_type: 0,
          audio: 'both',
          auto_recording: 'none'
        }
      })
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Failed to create Zoom meeting');
    }

    const meeting = await response.json();
    toast.success('Zoom meeting created successfully!');
    
    return {
      id: meeting.id,
      join_url: meeting.join_url,
      password: meeting.password,
      start_url: meeting.start_url
    };
  } catch (error) {
    console.error('Error creating Zoom meeting:', error);
    toast.error('Failed to create Zoom meeting');
    throw error;
  }
}