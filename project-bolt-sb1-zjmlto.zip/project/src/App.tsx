import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import Header from './components/Header';
import Hero from './components/Hero';
import RegistrationForm from './components/RegistrationForm';
import LoginForm from './components/LoginForm';
import Chatbot from './components/Chatbot';
import Dashboard from './components/Dashboard';
import AdminDashboard from './components/AdminDashboard';
import PrivacyPolicy from './pages/PrivacyPolicy';
import TermsOfService from './pages/TermsOfService';
import Footer from './components/Footer';
import { initDb } from './lib/db';
import type { Student } from './lib/db';

function App() {
  const [showRegistration, setShowRegistration] = useState(false);
  const [showLogin, setShowLogin] = useState(false);
  const [studentData, setStudentData] = useState<Omit<Student, 'password'> | null>(null);
  const [dbInitialized, setDbInitialized] = useState(false);

  useEffect(() => {
    initDb()
      .then(() => setDbInitialized(true))
      .catch(console.error);
  }, []);

  const handleRegistration = (data: Omit<Student, 'password'>) => {
    setStudentData(data);
    setShowRegistration(false);
  };

  const handleLogin = (data: Omit<Student, 'password'>) => {
    setStudentData(data);
    setShowLogin(false);
  };

  const handleLogout = () => {
    setStudentData(null);
  };

  if (!dbInitialized) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-pulse text-blue-600 text-lg">Loading...</div>
      </div>
    );
  }

  return (
    <Router>
      <div className="min-h-screen bg-gray-50 flex flex-col">
        <Toaster position="top-center" />
        <Header 
          userName={studentData?.name}
          onRegisterClick={() => setShowRegistration(true)}
          onLoginClick={() => setShowLogin(true)}
          onLogoutClick={handleLogout}
          isLoggedIn={!!studentData}
        />
        
        <main className="flex-grow">
          <Routes>
            <Route path="/privacy" element={<PrivacyPolicy />} />
            <Route path="/terms" element={<TermsOfService />} />
            <Route path="/" element={
              <>
                {studentData ? (
                  studentData.isAdmin ? (
                    <AdminDashboard />
                  ) : (
                    <Dashboard student={studentData} />
                  )
                ) : (
                  <Hero onRegisterClick={() => setShowRegistration(true)} />
                )}
                
                <Chatbot />
                
                {showRegistration && (
                  <RegistrationForm 
                    onSubmit={handleRegistration}
                    onClose={() => setShowRegistration(false)}
                  />
                )}

                {showLogin && (
                  <LoginForm
                    onLogin={handleLogin}
                    onClose={() => setShowLogin(false)}
                  />
                )}
              </>
            } />
          </Routes>
        </main>

        <Footer />
      </div>
    </Router>
  );
}

export default App;