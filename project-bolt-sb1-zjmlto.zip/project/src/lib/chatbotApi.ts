import toast from 'react-hot-toast';

const WEBHOOK_URL = 'https://hook.eu2.make.com/mclgae9nnoyup46a5vul2dm1tf8twu2q';

export async function findResponse(userInput: string): Promise<string> {
  try {
    const response = await fetch(WEBHOOK_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ 
        question: userInput,
        timestamp: new Date().toISOString()
      }),
    });

    if (!response.ok) {
      throw new Error('Failed to get response from webhook');
    }

    const data = await response.json();
    return data.answer || "I apologize, but I couldn't find a specific answer. Would you like to schedule a consultation with our advisors?";
  } catch (error) {
    console.error('Chatbot API Error:', error);
    toast.error('Failed to get response');
    return "I'm having trouble connecting right now. Would you like to schedule a consultation instead?";
  }
}