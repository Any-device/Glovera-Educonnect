import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

export default function TermsOfService() {
  return (
    <div className="min-h-screen bg-gray-50 pt-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Link 
          to="/" 
          className="inline-flex items-center text-blue-600 hover:text-blue-700 mb-6"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Home
        </Link>

        <div className="bg-white rounded-2xl shadow-sm p-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-6">Terms of Service</h1>
          
          <div className="prose max-w-none">
            <p className="text-gray-600 mb-6">
              Last updated: {new Date().toLocaleDateString()}
            </p>

            <section className="mb-8">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">1. Acceptance of Terms</h2>
              <p className="text-gray-700">
                By accessing and using EduConnect's services, you agree to be bound by these Terms of Service. 
                If you disagree with any part of these terms, you may not access our services.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">2. Services Description</h2>
              <p className="text-gray-700 mb-4">
                EduConnect provides:
              </p>
              <ul className="list-disc pl-6 text-gray-700 space-y-2">
                <li>Educational counseling services</li>
                <li>Virtual consultations via video conferencing</li>
                <li>AI-powered chat assistance</li>
                <li>Document review and recommendations</li>
                <li>University application guidance</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">3. User Responsibilities</h2>
              <p className="text-gray-700 mb-4">
                Users must:
              </p>
              <ul className="list-disc pl-6 text-gray-700 space-y-2">
                <li>Provide accurate and complete information</li>
                <li>Maintain the confidentiality of their account</li>
                <li>Not share access to their account</li>
                <li>Attend scheduled sessions punctually</li>
                <li>Respect intellectual property rights</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">4. Payment and Refunds</h2>
              <p className="text-gray-700 mb-4">
                Our payment terms include:
              </p>
              <ul className="list-disc pl-6 text-gray-700 space-y-2">
                <li>All fees are non-refundable unless otherwise stated</li>
                <li>24-hour cancellation policy for scheduled sessions</li>
                <li>Rescheduling is subject to availability</li>
                <li>Payment is required before service delivery</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">5. Intellectual Property</h2>
              <p className="text-gray-700">
                All content, features, and functionality of our services are owned by EduConnect 
                and are protected by international copyright, trademark, and other intellectual property laws.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">6. Limitation of Liability</h2>
              <p className="text-gray-700">
                EduConnect shall not be liable for any indirect, incidental, special, consequential, 
                or punitive damages resulting from your use or inability to use our services.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">7. Termination</h2>
              <p className="text-gray-700">
                We reserve the right to terminate or suspend access to our services immediately, 
                without prior notice, for any violation of these Terms of Service.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-900 mb-4">8. Contact Information</h2>
              <p className="text-gray-700">
                For questions about these Terms of Service, please contact us at:
              </p>
              <ul className="list-none text-gray-700 mt-2">
                <li>Email: legal@educonnect.com</li>
                <li>Phone: +1 (555) 123-4567</li>
                <li>Address: 123 Education Street, Suite 100, San Francisco, CA 94105</li>
              </ul>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
}