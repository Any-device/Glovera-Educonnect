import React, { useEffect, useRef, useState } from 'react';
import { Bot, Send, X, Video, VideoOff, Mic, MicOff } from 'lucide-react';
import toast from 'react-hot-toast';
import { generateResponse, type HeyGenResponse } from '../lib/heygenApi';

interface Message {
  role: 'user' | 'assistant';
  content: string;
  videoUrl?: string;
}

interface InteractiveAvatarProps {
  onClose: () => void;
}

export default function InteractiveAvatar({ onClose }: InteractiveAvatarProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [hasMediaPermissions, setHasMediaPermissions] = useState(false);
  const [isVideoEnabled, setIsVideoEnabled] = useState(true);
  const [isAudioEnabled, setIsAudioEnabled] = useState(true);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const userVideoRef = useRef<HTMLVideoElement>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    setMessages([
      {
        role: 'assistant',
        content: 'Hi! I\'m your admissions advisor. How can I help you today?',
      }
    ]);
    initializeMedia();
    
    return () => {
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const initializeMedia = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true
      });
      
      mediaStreamRef.current = stream;
      if (userVideoRef.current) {
        userVideoRef.current.srcObject = stream;
      }
      setHasMediaPermissions(true);
      toast.success('Camera and microphone connected!');
    } catch (error) {
      console.error('Media access error:', error);
      toast.error('Unable to access camera or microphone');
      setHasMediaPermissions(false);
    }
  };

  const toggleVideo = () => {
    if (mediaStreamRef.current) {
      const videoTrack = mediaStreamRef.current.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.enabled = !videoTrack.enabled;
        setIsVideoEnabled(videoTrack.enabled);
      }
    }
  };

  const toggleAudio = () => {
    if (mediaStreamRef.current) {
      const audioTrack = mediaStreamRef.current.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = !audioTrack.enabled;
        setIsAudioEnabled(audioTrack.enabled);
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setIsLoading(true);

    try {
      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: 'Generating response...' 
      }]);

      await generateResponse(
        userMessage,
        (chunk: HeyGenResponse) => {
          setMessages(prev => {
            const newMessages = [...prev];
            if (newMessages[newMessages.length - 1].role === 'assistant') {
              newMessages[newMessages.length - 1] = {
                role: 'assistant',
                content: chunk.text,
                videoUrl: chunk.videoUrl
              };
            }
            return newMessages;
          });

          if (chunk.videoUrl && videoRef.current) {
            videoRef.current.src = chunk.videoUrl;
            videoRef.current.play().catch(console.error);
          }
        },
        (error: Error) => {
          toast.error(error.message);
          setMessages(prev => prev.slice(0, -1));
        }
      );
    } catch (error) {
      toast.error('Failed to generate response');
      setMessages(prev => prev.slice(0, -1));
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="h-full flex flex-col bg-white">
      <div className="p-4 bg-blue-600 text-white flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <Bot className="w-6 h-6" />
          <h3 className="font-medium text-lg">Interactive Advisor</h3>
        </div>
        <div className="flex items-center space-x-4">
          {hasMediaPermissions && (
            <>
              <button 
                onClick={toggleVideo}
                className="hover:text-gray-200 transition-colors"
                title={isVideoEnabled ? 'Disable video' : 'Enable video'}
              >
                {isVideoEnabled ? <Video className="w-5 h-5" /> : <VideoOff className="w-5 h-5" />}
              </button>
              <button 
                onClick={toggleAudio}
                className="hover:text-gray-200 transition-colors"
                title={isAudioEnabled ? 'Disable microphone' : 'Enable microphone'}
              >
                {isAudioEnabled ? <Mic className="w-5 h-5" /> : <MicOff className="w-5 h-5" />}
              </button>
            </>
          )}
          <button onClick={onClose} className="hover:text-gray-200">
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="flex-1 grid grid-cols-2 gap-4 p-4 overflow-y-auto">
        <div className="space-y-4">
          <div className="relative rounded-lg overflow-hidden bg-gray-900 aspect-video">
            <video
              ref={videoRef}
              className="w-full h-full object-cover"
              autoPlay
              playsInline
              muted={false}
              controls
            />
          </div>
          {hasMediaPermissions && (
            <div className="relative rounded-lg overflow-hidden bg-gray-900 aspect-video">
              <video
                ref={userVideoRef}
                className="w-full h-full object-cover mirror"
                autoPlay
                playsInline
                muted
              />
            </div>
          )}
        </div>

        <div className="flex flex-col bg-gray-50 rounded-lg p-4">
          <div className="flex-1 overflow-y-auto">
            <div className="space-y-4">
              {messages.map((message, index) => (
                <div
                  key={index}
                  className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[90%] rounded-lg p-4 ${
                      message.role === 'user'
                        ? 'bg-blue-600 text-white'
                        : 'bg-white text-gray-800 shadow-sm'
                    }`}
                  >
                    {message.content}
                  </div>
                </div>
              ))}
              {isLoading && (
                <div className="flex justify-start">
                  <div className="bg-white rounded-lg p-4 shadow-sm">
                    <div className="flex space-x-2">
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" />
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-100" />
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-200" />
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          </div>

          <form onSubmit={handleSubmit} className="mt-4 flex space-x-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Type your message..."
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white"
              disabled={isLoading}
            />
            <button
              type="submit"
              className="bg-blue-600 text-white p-2 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
              disabled={isLoading}
            >
              <Send className="w-5 h-5" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}