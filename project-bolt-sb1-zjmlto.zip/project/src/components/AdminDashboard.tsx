import React, { useEffect, useState } from 'react';
import { getAllStudents } from '../lib/db';
import { Users, Calendar, Mail, Phone, GraduationCap } from 'lucide-react';

interface Student {
  id?: number;
  name: string;
  email: string;
  phone: string;
  fatherName: string;
  education: string;
  preferredCourse: string;
  cgpa: number;
  createdAt?: Date;
}

export default function AdminDashboard() {
  const [students, setStudents] = useState<Student[]>([]);

  useEffect(() => {
    getAllStudents().then(setStudents);
  }, []);

  return (
    <div className="min-h-[calc(100vh-64px)] pt-16 bg-gray-50">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
          <div className="bg-blue-600 px-8 py-12 md:px-12">
            <div className="flex items-center space-x-4">
              <Users className="w-10 h-10 text-white" />
              <div>
                <h1 className="text-white text-3xl md:text-4xl font-bold">Admin Dashboard</h1>
                <p className="text-blue-100 mt-2 text-lg">Manage student registrations</p>
              </div>
            </div>
          </div>

          <div className="p-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-10">
              <div className="bg-gray-50 rounded-xl p-8">
                <div className="flex items-center space-x-3">
                  <Users className="w-6 h-6 text-blue-600" />
                  <h3 className="text-xl font-semibold">Total Students</h3>
                </div>
                <p className="text-4xl font-bold mt-4">{students.length}</p>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-4 text-left text-sm font-medium text-gray-500 uppercase tracking-wider">
                      Student
                    </th>
                    <th className="px-6 py-4 text-left text-sm font-medium text-gray-500 uppercase tracking-wider">
                      Contact
                    </th>
                    <th className="px-6 py-4 text-left text-sm font-medium text-gray-500 uppercase tracking-wider">
                      Education
                    </th>
                    <th className="px-6 py-4 text-left text-sm font-medium text-gray-500 uppercase tracking-wider">
                      Course
                    </th>
                    <th className="px-6 py-4 text-left text-sm font-medium text-gray-500 uppercase tracking-wider">
                      Registered
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {students.map((student) => (
                    <tr key={student.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4">
                        <div className="flex items-center">
                          <div>
                            <div className="text-base font-medium text-gray-900">
                              {student.name}
                            </div>
                            <div className="text-sm text-gray-500">
                              {student.fatherName}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-base text-gray-900 flex items-center">
                          <Mail className="w-4 h-4 mr-2" />
                          {student.email}
                        </div>
                        <div className="text-sm text-gray-500 flex items-center mt-1">
                          <Phone className="w-4 h-4 mr-2" />
                          {student.phone}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-base text-gray-900">
                          {student.education}
                        </div>
                        <div className="text-sm text-gray-500 flex items-center mt-1">
                          <GraduationCap className="w-4 h-4 mr-2" />
                          CGPA: {student.cgpa.toFixed(2)}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className="px-3 py-1 inline-flex text-sm leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                          {student.preferredCourse}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-500">
                        <div className="flex items-center">
                          <Calendar className="w-4 h-4 mr-2" />
                          {student.createdAt?.toLocaleDateString()}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}