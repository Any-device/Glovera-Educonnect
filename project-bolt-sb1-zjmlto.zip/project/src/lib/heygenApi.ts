import { fetchEventSource } from '@microsoft/fetch-event-source';

const HEYGEN_API_KEY = 'YmVjNmViN2U4M2U4NDM0MmI3YmFlZmY0N2RhYTY0MGQtMTczMjQ1MDc0Nw==';
const AVATAR_ID = '37f4d912aa564663a1cf8d63acd0e1ab';
const API_URL = 'https://api.heygen.com/v2/video.generate';

export interface HeyGenResponse {
  text: string;
  videoUrl?: string;
}

export async function generateResponse(
  message: string,
  onChunk: (chunk: HeyGenResponse) => void,
  onError: (error: Error) => void
) {
  try {
    // Validate inputs
    if (!message.trim()) {
      throw new Error('Message cannot be empty');
    }

    const payload = {
      video: {
        avatar: {
          avatar_id: AVATAR_ID,
          avatar_style: 'normal'
        },
        background: {
          type: 'color',
          color: '#ffffff'
        },
        voice: {
          type: 'text',
          input_text: message,
          voice_id: 'en-US-Jenny'
        }
      }
    };

    const response = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'X-Api-Key': HEYGEN_API_KEY,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(
        data.message || `API request failed: ${response.status} ${response.statusText}`
      );
    }

    if (!data.data?.video_url) {
      throw new Error('No video URL in response');
    }

    // Success case
    onChunk({
      text: message,
      videoUrl: data.data.video_url
    });

  } catch (error) {
    console.error('HeyGen API Error:', error);
    onError(error instanceof Error ? error : new Error('Failed to generate response'));
  }
}