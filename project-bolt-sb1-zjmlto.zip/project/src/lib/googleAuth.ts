import toast from 'react-hot-toast';

const CLIENT_ID = import.meta.env.VITE_GOOGLE_CLIENT_ID;
const API_KEY = import.meta.env.VITE_GOOGLE_API_KEY;
const DISCOVERY_DOC = 'https://www.googleapis.com/discovery/v1/apis/calendar/v3/rest';
const SCOPES = 'https://www.googleapis.com/auth/calendar https://www.googleapis.com/auth/spreadsheets';

let tokenClient: google.accounts.oauth2.TokenClient;

export async function initializeGoogleApi() {
  try {
    await new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = 'https://accounts.google.com/gsi/client';
      script.async = true;
      script.defer = true;
      script.onload = resolve;
      script.onerror = reject;
      document.head.appendChild(script);
    });

    await new Promise<void>((resolve) => {
      gapi.load('client', async () => {
        try {
          await gapi.client.init({
            apiKey: API_KEY,
            discoveryDocs: [
              DISCOVERY_DOC,
              'https://sheets.googleapis.com/$discovery/rest?version=v4'
            ],
          });
          resolve();
        } catch (error) {
          console.error('Error initializing gapi client:', error);
          toast.error('Failed to initialize Google services');
        }
      });
    });

    tokenClient = google.accounts.oauth2.initTokenClient({
      client_id: CLIENT_ID,
      scope: SCOPES,
      callback: '', // Will be set later
    });

  } catch (error) {
    console.error('Error loading Google API:', error);
    toast.error('Failed to load Google services');
  }
}

export async function getAuthToken(): Promise<string> {
  return new Promise((resolve, reject) => {
    try {
      tokenClient.callback = async (response) => {
        if (response.error) {
          reject(response.error);
          return;
        }
        resolve(response.access_token);
      };
      
      if (gapi.client.getToken() === null) {
        tokenClient.requestAccessToken({ prompt: 'consent' });
      } else {
        tokenClient.requestAccessToken({ prompt: '' });
      }
    } catch (error) {
      reject(error);
    }
  });
}

export async function createCalendarEvent(event: {
  summary: string;
  description: string;
  start: { dateTime: string; timeZone: string };
  end: { dateTime: string; timeZone: string };
  attendees: { email: string }[];
  conferenceData?: any;
}) {
  try {
    await getAuthToken();
    const response = await gapi.client.calendar.events.insert({
      calendarId: 'primary',
      conferenceDataVersion: 1,
      resource: event,
    });
    
    if (response.result) {
      toast.success('Calendar event created successfully!');
      return response.result;
    } else {
      throw new Error('Failed to create calendar event');
    }
  } catch (error) {
    console.error('Error creating calendar event:', error);
    toast.error('Failed to create calendar event');
    throw error;
  }
}