import React, { useState } from 'react';
import { Calendar, GraduationCap, BookOpen, Clock } from 'lucide-react';
import ScheduleConsultation from './ScheduleConsultation';
import toast from 'react-hot-toast';

interface DashboardProps {
  student: {
    name: string;
    email: string;
    phone: string;
    fatherName: string;
    education: string;
    preferredCourse: string;
    cgpa?: number;
  };
}

export default function Dashboard({ student }: DashboardProps) {
  const [showScheduling, setShowScheduling] = useState(false);

  const handleScheduleClick = () => {
    if (!student.email || !student.name) {
      toast.error('Student information is incomplete');
      return;
    }
    setShowScheduling(true);
  };

  return (
    <div className="min-h-[calc(100vh-64px)] pt-16 bg-gray-50">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
          {/* Header */}
          <div className="bg-blue-600 px-8 py-12 md:px-12">
            <h1 className="text-white text-3xl md:text-4xl font-bold">Welcome, {student.name}!</h1>
            <p className="text-blue-100 mt-2 text-lg">Your personalized admissions dashboard</p>
          </div>

          {/* Main Content */}
          <div className="p-8 md:p-12 space-y-10">
            {/* Quick Actions */}
            <div className="bg-blue-50 rounded-xl p-8 border border-blue-100">
              <h2 className="text-2xl font-semibold text-blue-900 mb-6">Ready to Start Your Journey?</h2>
              <button 
                onClick={handleScheduleClick}
                className="inline-flex items-center px-8 py-4 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-lg"
              >
                <Calendar className="w-6 h-6 mr-3" />
                Schedule Your Consultation
              </button>
              <p className="mt-4 text-blue-700 text-lg">
                Meet with our expert advisor to discuss your U.S. education goals
              </p>
            </div>

            {/* Student Info Section */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <div className="bg-gray-50 rounded-xl p-8">
                <div className="flex items-start space-x-4">
                  <div className="bg-blue-100 p-4 rounded-lg">
                    <GraduationCap className="w-8 h-8 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900">Education</h3>
                    <p className="mt-3 text-gray-600 text-lg">{student.education}</p>
                    {typeof student.cgpa === 'number' && (
                      <p className="mt-2 text-blue-600 font-semibold">
                        CGPA: {student.cgpa.toFixed(2)}
                      </p>
                    )}
                  </div>
                </div>
              </div>

              <div className="bg-gray-50 rounded-xl p-8">
                <div className="flex items-start space-x-4">
                  <div className="bg-blue-100 p-4 rounded-lg">
                    <BookOpen className="w-8 h-8 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900">Preferred Course</h3>
                    <p className="mt-3 text-gray-600 text-lg">{student.preferredCourse}</p>
                  </div>
                </div>
              </div>

              <div className="bg-gray-50 rounded-xl p-8">
                <div className="flex items-start space-x-4">
                  <div className="bg-blue-100 p-4 rounded-lg">
                    <Clock className="w-8 h-8 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900">Next Steps</h3>
                    <p className="mt-3 text-gray-600 text-lg">Schedule your consultation to begin your journey</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Contact Info */}
            <div className="bg-gray-50 rounded-xl p-8">
              <h2 className="text-2xl font-semibold mb-6">Your Contact Information</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <p className="text-gray-600 text-lg">Email</p>
                  <p className="font-medium text-xl mt-1">{student.email}</p>
                </div>
                <div>
                  <p className="text-gray-600 text-lg">Phone</p>
                  <p className="font-medium text-xl mt-1">{student.phone}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {showScheduling && (
        <ScheduleConsultation
          onClose={() => setShowScheduling(false)}
          studentEmail={student.email}
          studentName={student.name}
        />
      )}
    </div>
  );
}