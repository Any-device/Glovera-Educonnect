import Dexie, { Table } from 'dexie';
import bcrypt from 'bcryptjs';
import toast from 'react-hot-toast';

export interface Student {
  id?: number;
  name: string;
  email: string;
  phone: string;
  fatherName: string;
  education: string;
  preferredCourse: string;
  cgpa: number;
  password: string;
  createdAt?: Date;
  isAdmin?: boolean;
}

class StudentDatabase extends Dexie {
  students!: Table<Student>;

  constructor() {
    super('StudentDB');
    this.version(1).stores({
      students: '++id, email, createdAt, isAdmin'
    });
  }
}

const db = new StudentDatabase();

export async function initDb() {
  try {
    if (!db.isOpen()) {
      await db.open();
      const adminExists = await db.students.where('email').equals('admin@educonnect.com').first();
      if (!adminExists) {
        const hashedPassword = await bcrypt.hash('admin123', 10);
        await db.students.add({
          name: 'Admin',
          email: 'admin@educonnect.com',
          phone: '',
          fatherName: '',
          education: '',
          preferredCourse: '',
          cgpa: 0,
          password: hashedPassword,
          isAdmin: true,
          createdAt: new Date()
        });
      }
    }
    return db;
  } catch (error) {
    console.error('Database initialization error:', error);
    toast.error('Failed to initialize database');
    throw error;
  }
}

export async function saveStudent(data: Omit<Student, 'id' | 'createdAt' | 'isAdmin'>) {
  try {
    const db = await initDb();
    
    if (!data.email?.trim() || !data.password?.trim() || !data.name?.trim()) {
      throw new Error('Required fields are missing');
    }

    const existingStudent = await db.students.where('email').equals(data.email.trim()).first();
    if (existingStudent) {
      throw new Error('Email already registered');
    }

    const hashedPassword = await bcrypt.hash(data.password, 10);
    
    const studentData = {
      ...data,
      email: data.email.trim(),
      password: hashedPassword,
      isAdmin: false,
      createdAt: new Date()
    };

    const id = await db.students.add(studentData);
    const student = await db.students.get(id);
    
    if (!student) {
      throw new Error('Failed to create student account');
    }

    const { password: _, ...studentWithoutPassword } = student;
    toast.success('Registration successful! Data saved to database.');
    return studentWithoutPassword;
  } catch (error) {
    console.error('Save student error:', error);
    throw error;
  }
}

export async function loginStudent(email: string, password: string): Promise<Omit<Student, 'password'>> {
  try {
    const db = await initDb();

    if (!email?.trim() || !password?.trim()) {
      throw new Error('Email and password are required');
    }

    const student = await db.students.where('email').equals(email.trim()).first();
    
    if (!student) {
      throw new Error('Invalid email or password');
    }

    const isValid = await bcrypt.compare(password, student.password);
    if (!isValid) {
      throw new Error('Invalid email or password');
    }

    const { password: _, ...studentData } = student;
    toast.success('Login successful!');
    return studentData;
  } catch (error) {
    console.error('Login error:', error);
    throw error;
  }
}

export async function getAllStudents(): Promise<Omit<Student, 'password'>[]> {
  try {
    const db = await initDb();
    const students = await db.students
      .filter(student => !student.isAdmin)
      .reverse()
      .sortBy('createdAt');
    
    return students.map(({ password: _, ...student }) => student);
  } catch (error) {
    console.error('Get all students error:', error);
    toast.error('Failed to fetch students');
    throw error;
  }
}