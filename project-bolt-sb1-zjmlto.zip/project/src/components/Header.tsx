import React from 'react';
import { UserCircle2, LogIn, LogOut } from 'lucide-react';

interface HeaderProps {
  userName?: string;
  onRegisterClick: () => void;
  onLoginClick: () => void;
  onLogoutClick: () => void;
  isLoggedIn: boolean;
}

export default function Header({ 
  userName, 
  onRegisterClick, 
  onLoginClick,
  onLogoutClick,
  isLoggedIn 
}: HeaderProps) {
  return (
    <header className="fixed top-0 w-full bg-white shadow-sm z-40">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <h1 className="text-2xl font-bold text-blue-600">EduConnect</h1>
        </div>
        
        {isLoggedIn ? (
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <UserCircle2 className="w-6 h-6 text-blue-600" />
              <span className="font-medium">Welcome, {userName}!</span>
            </div>
            <button
              onClick={onLogoutClick}
              className="inline-flex items-center space-x-2 text-gray-600 hover:text-gray-800"
            >
              <LogOut className="w-5 h-5" />
              <span>Logout</span>
            </button>
          </div>
        ) : (
          <div className="flex items-center space-x-4">
            <button
              onClick={onLoginClick}
              className="inline-flex items-center space-x-2 text-gray-600 hover:text-gray-800"
            >
              <LogIn className="w-5 h-5" />
              <span>Login</span>
            </button>
            <button
              onClick={onRegisterClick}
              className="bg-blue-600 text-white px-6 py-2 rounded-full hover:bg-blue-700 transition-colors"
            >
              Register Now
            </button>
          </div>
        )}
      </nav>
    </header>
  );
}